<?php

class OAuth2Client
{
    const ACCESS_TOKEN_EXPIRES = 3600;

    /**
     * Supported algs. Currently we are using RS256, but others may be useful for future.
     */
    public static $supportedAlgs = [
        'HS256' => ['hash_hmac', 'SHA256'],
        'HS512' => ['hash_hmac', 'SHA512'],
        'HS384' => ['hash_hmac', 'SHA384'],
        'RS256' => ['openssl', 'SHA256'],
    ];

    /**
     * Generates new access token from the given content
     * @param array $content
     * @param null $privateKey
     * @return mixed
     * @throws Exception
     */
    public static function generateAccessToken($content = [], $privateKey = null)
    {
        if (!is_array($content)) {
            throw new Exception('Content for new access token should has an array type', 400);
        }
        if (!count($content)) {
            throw new Exception('Content for new access token can not be empty', 400);
        }
        // Convert content to JSON object
        $jsonContent = Utilities::jsonEncode((object)$content);
        // Add sign to access token to verify it later
        // Generate the sign
        if (!$privateKey) {
            $privateKey = openssl_pkey_get_private(PK_LOCATION);
        }
        $sign = OAuth2Client::sign($jsonContent, $privateKey);
        // Add sign to content
        $content['signature'] = Utilities::urlsafeB64Encode($sign); // encode sign because it may contain commas
        // Convert content with signature to JSON
        $jsonContentWithSign = Utilities::jsonEncode((object)$content);
        // return Base64Encoded json object with signature
        return Utilities::urlsafeB64Encode($jsonContentWithSign);
    }

    /**
     * Validates access token
     * @param $token
     * @param $currentTimestamp
     * @param null $privateKey
     * @return bool
     * @throws Exception
     */
    public static function validAccessToken($token, $currentTimestamp, $privateKey = null)
    {
        // Catch url decode and json decode errors
        try {
            // Decode token
            $base64Decoded = Utilities::urlsafeB64Decode($token);
            // JSON decode
            $accessToken = Utilities::jsonDecode($base64Decoded);
        } catch(Exception $e) {
            throw new OAuth2Exception('Token is invalid', 403);
        }
        // Check for required params
        if (!isset($accessToken->user_email)) {
            throw new OAuth2Exception('Token is invalid', 403);
        }
        if (!isset($accessToken->expires)) {
            throw new OAuth2Exception('Token is invalid', 403);
        }
        if ($accessToken->expires < $currentTimestamp) {
            throw new OAuth2Exception('Token has expired', 403);
        }
        if (!isset($accessToken->signature)) {
            throw new OAuth2Exception('Token is invalid', 403);
        }
        // Verify the signature from access token
        $tokenSign = $accessToken->signature;
        unset($accessToken->signature);
        // Generate the sign
        if (!$privateKey) {
            $privateKey = openssl_pkey_get_private(PK_LOCATION);
        }
        $sign = Utilities::urlsafeB64Encode(OAuth2Client::sign(Utilities::jsonEncode($accessToken), $privateKey, 'RS256'));
        // Compare two signs
        if ($sign !== $tokenSign) {
            throw new OAuth2Exception('Token is invalid', 403);
        }
        return true;
    }

    /**
     * Extracts client id from payload(Claim set)
     * @param $jwt
     * @return mixed
     * @throws Exception
     */
    public static function getClientId($jwt)
    {
        $segments = explode('.', $jwt);
        if (count($segments) != 3) {
            throw new OAuth2Exception('Wrong number of segments');
        }
        if (null === $payload = Utilities::jsonDecode(Utilities::urlsafeB64Decode($segments[1]))) {
            throw new OAuth2Exception('Invalid claims encoding');
        }
        if (!isset($payload->iss)) {
            throw new OAuth2Exception('Missing required iss param in payload');
        }
        return $payload->iss;
    }

    /**
     * Decodes a JWT string into a PHP object.
     * @param $jwt
     * @param $key
     * @return mixed
     * @throws Exception
     */
    public static function decode($jwt, $key)
    {
        if (empty($key)) {
            throw new OAuth2Exception('Key may not be empty');
        }
        $segments = explode('.', $jwt);
        if (count($segments) != 3) {
            throw new OAuth2Exception('Wrong number of segments');
        }
        list($headb64, $bodyb64, $cryptob64) = $segments;
        if (null === ($header = Utilities::jsonDecode(Utilities::urlsafeB64Decode($headb64)))) {
            throw new OAuth2Exception('Invalid header encoding');
        }
        if (null === $payload = Utilities::jsonDecode(Utilities::urlsafeB64Decode($bodyb64))) {
            throw new OAuth2Exception('Invalid claims encoding');
        }
        $sig = Utilities::urlsafeB64Decode($cryptob64);

        if (empty($header->alg)) {
            throw new OAuth2Exception('Empty algorithm', 400);
        }
        if (empty(self::$supportedAlgs[$header->alg])) {
            throw new OAuth2Exception('Algorithm not supported', 400);
        }
        // Check the signature
        if (!self::verify("$headb64.$bodyb64", $sig, $key, $header->alg)) {
            throw new OAuth2Exception('Invalid RSA-256 Signature', 400);
        }
        return $payload;
    }

    /**
     * Converts and signs a PHP object or array into a JWT string.
     * @param $payload
     * @param $key
     * @param string $alg
     * @return string
     * @throws Exception
     */
    public static function encode($payload, $key, $alg = 'RS256')
    {
        $header = ['typ' => 'JWT', 'alg' => $alg];

        $segments = [];
        $segments[] = Utilities::urlsafeB64Encode(Utilities::jsonEncode($header));
        $segments[] = Utilities::urlsafeB64Encode(Utilities::jsonEncode($payload));
        $signingInput = implode('.', $segments);
        $signature = OAuth2Client::sign($signingInput, $key, $alg);
        $segments[] = Utilities::urlsafeB64Encode($signature);
        return implode('.', $segments);
    }

    /**
     * Sign a string with a given key and algorithm.
     * @param $msg
     * @param $key
     * @param string $alg
     * @return string
     * @throws Exception
     */
    public static function sign($msg, $key, $alg = 'RS256')
    {
        if (empty(self::$supportedAlgs[$alg])) {
            throw new Exception('Algorithm not supported', 400);
        }
        list($function, $algorithm) = self::$supportedAlgs[$alg];
        switch($function) {
            case 'hash_hmac':
                return hash_hmac($algorithm, $msg, $key, true);
            case 'openssl':
                $signature = '';
                $success = openssl_sign($msg, $signature, $key, $algorithm);
                if (!$success) {
                    throw new Exception("OpenSSL unable to sign data", 400);
                } else {
                    return $signature;
                }
        }
    }

    /**
     * Verify a signature with the message, key and method
     * @param $msg
     * @param $signature
     * @param $key
     * @param $alg
     * @return bool
     * @throws Exception
     */
    private static function verify($msg, $signature, $key, $alg)
    {
        if (empty(self::$supportedAlgs[$alg])) {
            throw new OAuth2Exception('Algorithm not supported', 400);
        }
        list($function, $algorithm) = self::$supportedAlgs[$alg];
        switch($function) {
            case 'openssl':
                $success = openssl_verify($msg, $signature, $key, $algorithm);
                if (!$success) {
                    throw new OAuth2Exception("Invalid RSA-256 Signature", 400);
                } else {
                    return $signature;
                }
                break;
            case 'hash_hmac':
            default:
                $hash = hash_hmac($algorithm, $msg, $key, true);
                if (function_exists('hash_equals')) {
                    return hash_equals($signature, $hash);
                }
                $len = min(Utilities::safeStrlen($signature), Utilities::safeStrlen($hash));
                $status = 0;
                for ($i = 0; $i < $len; $i++) {
                    $status |= (ord($signature[$i]) ^ ord($hash[$i]));
                }
                $status |= (Utilities::safeStrlen($signature) ^ Utilities::safeStrlen($hash));
                return ($status === 0);
        }
    }

    /**
     * Decrypts token
     * @param $token
     * @param null $privateKey
     * @return mixed
     * @throws Exception
     */
    public static function decryptAccessToken($token, $privateKey = null)
    {
        if (!$privateKey) {
            $privateKey = openssl_pkey_get_private(PK_LOCATION);
        }
        $decoded = Utilities::urlsafeB64Decode($token);
        // Decrypt content with server's private key
        if (!openssl_private_decrypt($decoded, $decrypted, $privateKey)) {
            throw new Exception("OpenSSL unable to decrypt data: " . openssl_error_string(), 400);
        }
        return Utilities::jsonDecode($decrypted);
    }

    /**
     * Returns access token from request header
     * @return bool
     * @throws Exception
     */
    public static function getOAuthTokenFromRequest()
    {
        $headers = getallheaders();
        // Empty header info (
        if (!$headers) {
            throw new OAuth2Exception('Authentication required', 401);
        }
        // Set access token as false by default
        $accessToken = false;
        foreach ($headers as $name => $value) {
            if ($name == 'Authorization') {
                $accessToken = $value;
            }
        }
        // if there is no access token in header
        if (!$accessToken) {
            throw new OAuth2Exception('Authentication required', 401);
        }
        $accessToken = str_replace('Bearer', '', $accessToken);

        return $accessToken;
    }
}