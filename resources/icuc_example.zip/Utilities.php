<?php

class Utilities
{
    /**
     * Decode a JSON string into a PHP object.
     * @param $input
     * @return mixed
     * @throws Exception
     */
    public static function jsonDecode($input)
    {
        if (version_compare(PHP_VERSION, '5.4.0', '>=') && !(defined('JSON_C_VERSION') && PHP_INT_SIZE > 4)) {
            /** In PHP >=5.4.0, json_decode() accepts an options parameter, that allows you
             * to specify that large ints (like Steam Transaction IDs) should be treated as
             * strings, rather than the PHP default behaviour of converting them to floats.
             */
            $obj = json_decode($input, false, 512, JSON_BIGINT_AS_STRING);
        } else {
            /** Not all servers will support that, however, so for older versions we must
             * manually detect large ints in the JSON string and quote them (thus converting
             *them to strings) before decoding, hence the preg_replace() call.
             */
            $max_int_length = strlen((string) PHP_INT_MAX) - 1;
            $json_without_bigints = preg_replace('/:\s*(-?\d{'.$max_int_length.',})/', ': "$1"', $input);
            $obj = json_decode($json_without_bigints);
        }
        if (function_exists('json_last_error') && $errno = json_last_error()) {
            self::handleJsonError($errno);
        } elseif ($obj === null && $input !== 'null') {
            throw new Exception('Null result with non-null input', 400);
        }
        return $obj;
    }

    /**
     * Encode a PHP object into a JSON string.
     */
    public static function jsonEncode($input)
    {
        $json = json_encode($input);
        if (function_exists('json_last_error') && $errno = json_last_error()) {
            self::handleJsonError($errno);
        } elseif ($json === 'null' && $input !== null) {
            throw new Exception('Null result with non-null input', 400);
        }
        return $json;
    }

    /**
     * Decode a string with URL-safe Base64.
     * @param $b64
     * @return string
     */
    public static function urlSafeB64Decode($b64)
    {
        $b64 = str_replace(
            array('-', '_'),
            array('+', '/'),
            $b64
        );
        return base64_decode($b64);
    }

    /**
     * Encode a string with URL-safe Base64.
     * @param $data
     * @return mixed
     */
    public static function urlSafeB64Encode($data)
    {
        $b64 = base64_encode($data);
        $b64 = str_replace(
            array('+', '/', '\r', '\n', '='),
            array('-', '_'),
            $b64
        );
        return $b64;
    }

    public static function urlReplaceEncode($b64)
    {
        $b64 = str_replace(
            array('+', '/', '\r', '\n', '='),
            array('-', '_'),
            $b64
        );
        return $b64;
    }

    public static function urlReplaceDecode($b64)
    {
        $b64 = str_replace(
            array('-', '_'),
            array('+', '/'),
            $b64
        );
        return $b64;
    }

    public static function toPemStyleKey($key)
    {
        return "-----BEGIN PUBLIC KEY-----
" . wordwrap($key, 64, "
", true) . "===================================================================================================
-----END PUBLIC KEY-----";
    }

    /**
     * Helper method to create a JSON error.
     * @param $errno
     * @throws Exception
     */
    private static function handleJsonError($errno)
    {
        $messages = [
            JSON_ERROR_DEPTH => 'Maximum stack depth exceeded',
            JSON_ERROR_CTRL_CHAR => 'Unexpected control character found',
            JSON_ERROR_SYNTAX => 'Syntax error, malformed JSON'
        ];
        throw new Exception(
            isset($messages[$errno])
                ? $messages[$errno]
                : 'Unknown JSON error: ' . $errno
        );
    }

    /**
     * Get the number of bytes in cryptographic strings.
     * @param $str
     * @return int
     */
    public static function safeStrlen($str)
    {
        if (function_exists('mb_strlen')) {
            return mb_strlen($str, '8bit');
        }
        return strlen($str);
    }
}