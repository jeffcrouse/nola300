<?php

require_once 'Utilities.php';
require_once 'OAuth2Client.php';

// example
$client = new SubmitClient();
// get the access token
$data = json_decode($client->refreshToken(), 1);
// send data to SocialPatrol
if (!empty($data['access_token'])) {
    echo $client->pushData($data['access_token']);
}


class SubmitClient
{
    const HOST = 'https://test.socialpatrol.net';
    const STREAM = 5004; // stream id
    const PR_KEY = 'file://mykey.pem'; // this is your private key file

    private function generateJWT()
    {
        // iss - is the service account email saved in SP's user table
        // exp and iat - those are required also but don't make difference in anything
        // 'iss' => 'jeff.crouse@toolofna.com',
        $claimSet = [
            'iss' => 'jeff.crouse@toolofna.com',
            'exp' => time('+1 hour'),
            'iat' => time('now')
        ];

        // this is a private key resource - we will need this for making a signature
        $privateKey = openssl_pkey_get_private(self::PR_KEY);
        // this is our JsonWebToken(JWT) containing 3 segments {header}.{payload}.{signature_made_from_header_and_payload}
        // header(standard: ['typ' => 'JWT', 'alg' => 'RS256'])
        // our payload ($claimSet)
        $assertion = \OAuth2Client::encode($claimSet, $privateKey);
        //echo $assertion;exit();
        // return as url query params, so we can pass it to curl post fields
        return http_build_query([
            'grant_type' => 'urn:ietf:params:oauth:grant-type:jwt-bearer',
            'assertion' => $assertion
        ]);
    }

    public function refreshToken()
    {
        if (!$curl_handle = curl_init()) {
            // cURL failed to start
            throw new Exception('cURL did not initialize properly.', 417);
        }

        curl_setopt($curl_handle, CURLOPT_POST, true);
        curl_setopt($curl_handle, CURLOPT_POSTFIELDS, $this->generateJWT());
        curl_setopt($curl_handle,CURLOPT_URL, self::HOST . '/service/oauth2/token');
        curl_setopt($curl_handle,CURLOPT_CONNECTTIMEOUT,6);
        curl_setopt($curl_handle,CURLOPT_RETURNTRANSFER,1);
        $response = curl_exec($curl_handle);
        // Check if any error occurred
        if(!curl_errno($curl_handle)) {
            $info = curl_getinfo($curl_handle);
            echo 'Response code: ' . $info['http_code'] . "\n";
        }
        curl_close($curl_handle);

        return $response;
    }

    public function pushData($accessToken)
    {
        $header = [
            'Authorization: Bearer' . $accessToken,
            'Content-Type: application/json'
        ];
        $id = md5(time());



        $images = [
            'http://animals.sandiegozoo.org/sites/default/files/2016-09/animals_hero_panda.jpg',
            'https://d1o50x50snmhul.cloudfront.net/wp-content/uploads/2017/07/17153147/gettyimages-590483570.jpg',
            'https://www-tc.pbs.org/wgbh/nova/assets/img/full-size/what-animals-thinking-merl.jpg',
            'https://www.toateanimalele.ro/wp-content/uploads/2017/01/pui-de-urs-polar-iarna.jpg'
        ];

        // TODO: here you need to put your videos data
        $body = '{"entries":[{"entryId":"'.$id.'", "callBackUrl":"'.self::HOST.'/api/external/callback", "image":{"imageUrl":"'.$images[rand(0,count($images) -1)].'", "imageType":"image/jpg"}, "entryTime":'.time().'}]}';


        if (!$curl_handle = curl_init()) {
            // cURL failed to start
            throw new Exception('cURL did not initialize properly.', 417);
        }
        curl_setopt($curl_handle, CURLOPT_HTTPHEADER, $header);
        curl_setopt($curl_handle, CURLOPT_POST,true);
        curl_setopt($curl_handle, CURLOPT_POSTFIELDS, $body);

        curl_setopt($curl_handle,CURLOPT_URL, self::HOST . '/service/delivery/'.self::STREAM.'/entries');
        curl_setopt($curl_handle,CURLOPT_CONNECTTIMEOUT,6);
        curl_setopt($curl_handle,CURLOPT_RETURNTRANSFER,1);
        $response = curl_exec($curl_handle);
        var_dump($response);
        // Check if any error occurred
        if(!curl_errno($curl_handle)) {
            $info = curl_getinfo($curl_handle);
            echo 'Response code: ' . $info['http_code'] . "\n";
        }
        curl_close($curl_handle);
    }
}